# Competition Radar —— 全链路闭环 MVP（国产模型 + 联网搜索）

面向大学生的竞赛搜索与个性化推荐智能体，ABCD 四人模块已全链路闭环：

```
输入画像 → 联网搜索(Bocha) + 抽取(DeepSeek国产模型) → 证据核验(B) → 资格/排序/归并(C) → 推荐展示(D)
```

核心承诺：**信息有证据、资格能筛选、缺失会追问、效果可评测、不确定不编造。**

## 快速开始

```powershell
# 1) 依赖（Python 3.12+）
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt -e .
pip install -r requirements-frontend.txt      # streamlit + requests

# 2) 配置：Copy-Item .env.example .env 并填入密钥（DeepSeek / Bocha）

# 3) 直接运行（无需记命令）
python main.py        # 后端 → http://127.0.0.1:8000/docs
python ui.py          # 前端 → http://localhost:8501
```

## 三个接口

| 接口 | 作用 |
|---|---|
| `POST /api/v1/library/recommend` | 71 个学院推荐竞赛按兴趣匹配 + **联网搜索补最新详情** + 过滤外校校赛 |
| `POST /api/v1/search` | 11 字段证据链路（研究→抽取→B核验→补搜→C推荐） |
| `POST /api/v1/search/full` | **31 字段全链路**（联网搜索→DeepSeek抽取→B核验→C消费→补全推荐） |

## 国产模型 + 联网搜索

- **抽取**：DeepSeek（`src/competition_radar/deepseek.py`，`DEEPSEEK_MODEL=deepseek-flash`）。
- **搜索**：Bocha（`web_search.py`，`SEARCH_PROVIDER=bocha` + `BOCHA_API_KEY`）；也支持 Tavily、DuckDuckGo。
- **模式**：`RESEARCHER_MODE` 取 `fixture`（离线真实快照）/ `real`（即时联网搜索）/ `mock`。
- **过滤**：`USER_SCHOOL=华南师范大学`，联网结果自动排除外校校赛（`campus:外校`）。
- 换通义/智谱/Kimi：改 `DEEPSEEK_BASE_URL`（OpenAI 兼容端点，见 `.env.example`）。

## 目录

```text
main.py / research_service.py / api_models.py / config.py   # A：后端入口、研究服务、配置
extractor.py / domestic_extract.py                          # 抽取（规则 + DeepSeek）
web_search.py                                               # 联网搜索（Bocha/Tavily/DDG + 抓正文）
evidence_verifier.py / query_planner.py                     # B 适配层
library_recommend.py / recommend_full.py / full_chain.py    # 库推荐 + 31字段补全 + 全链路
ui.py                                                       # D 前端
data/   (competition_library.json 71竞赛 / approved_sources / b_policy / b_canonical_batch)
src/competition_radar/   (C 模型规则 + deepseek + extraction + b_recommend/b_return)
src/b_app/               (B 核验/规划/自适应搜索 + frozen + service)
examples/  tests/  b_tests/  docs/
```

## 测试

```powershell
python -m pytest -q                              # 74 项
python -m unittest discover -s b_tests -q       # B 269 项
```

## 诚实边界

- 联网抓取的来源经**域名过滤**（`.edu.cn/.gov.cn/.org.cn` 优先、跳过博客论坛）+ **学校过滤**（排除外校校赛）双重把关，并一律标「待B核验」。
- 真实数据下多为「待确认」——因为 B 的冻结策略要求**官方（全国）来源**才能确认全国资格/截止，学校转载页不能独立证明；这是「不确定不编造」的体现。
- 详见 `全链路闭环完成报告.md`。
